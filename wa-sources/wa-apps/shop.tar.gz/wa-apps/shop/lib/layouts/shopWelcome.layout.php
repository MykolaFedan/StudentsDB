<?php
class shopWelcomeLayout extends waLayout
{
    public function execute()
    {

    }
}
